package com.example.login;

import android.util.Log;

public interface OtpListener {
    public void messageReceived(String messageText);
}
