<<<<<<< HEAD
<<<<<<< HEAD
MULTIPLE LOGIN OPTIONS 
UI GOOD
=======
# LoginOptions
All Login Options enabled

Email sign in and Sign up, Facebook Login, Google Log in, Phone OTP Login enabled
Good UI also
>>>>>>> 6091e4cedc07765dfce72195aa050f0d806a5794
=======

>>>>>>> e57d7b05f3b83bcba4ed49b360de3af3875552ec
